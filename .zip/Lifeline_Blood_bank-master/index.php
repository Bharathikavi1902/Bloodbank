<html>
<head>
	<title>Index Page</title>
	<link rel="icon" href="image/img.png" type="image" sizes="16x16">
	<link rel="stylesheet" type="text/css" href="css/index.css">
</head>
<h1>LIFELINE BLOOD BANK</h1>
<center>
<body>	
<div id="id1">
<form action="php/login.php" method="POST">

<input type="email" name="email" placeholder="E-mail...." required/><br>
<input type="password" name="password" placeholder="Password....." required/><br><br>
<input type="submit"  name="login" value="LOGIN">
<input type="reset" value="RESET">

</form>

<font color="white">If you are<b> new</b> to the website,then</font><br><br>

<form action="php/register.php" >
<input type="submit" value="SIGNUP">

</div>
</form>
</center>
</body>
</html>